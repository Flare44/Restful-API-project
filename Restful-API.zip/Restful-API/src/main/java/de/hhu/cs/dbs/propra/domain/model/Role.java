package de.hhu.cs.dbs.propra.domain.model;

public enum Role {
    NUTZER, KUNDE, PROJEKTLEITER;
}
